<?php
 
phpinfo();
 
?>
